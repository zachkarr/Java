package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Is296demoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Is296demoApplication.class, args);
	}

}
