package disburse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DisburseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DisburseApplication.class, args);
	}

}
